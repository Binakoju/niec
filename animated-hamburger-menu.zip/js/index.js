$(".button").click(function(){
 $(this).closest("body").toggleClass("active");
});