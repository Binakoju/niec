A Pen created at CodePen.io. You can find this one at http://codepen.io/netfuel/pen/rIlnB.

 This is a hamburger that tells you what it is on-hover and also has a close function. Maybe it would be better than putting the work menu under the icon?